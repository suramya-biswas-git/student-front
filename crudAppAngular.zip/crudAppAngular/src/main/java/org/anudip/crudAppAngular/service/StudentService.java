package org.anudip.crudAppAngular.service;


import org.anudip.crudAppAngular.bean.Student;
import org.springframework.stereotype.Service;

@Service
public class StudentService {
	public Student totalAndGradeCalculation(Student student)
	{
		double sub1=student.getSubject1();
		double sub2=student.getSubject2();
		double sub3=student.getSubject3();
		double total=sub1+sub2+sub3;
		student.setTotalMarks(total);
		double percentage=(total/300.00)*100.00;
		String grade="";
		if(percentage>=90)
			grade="E";
		else if (percentage>=75)
			grade="G";
		else if (percentage>=60)
			grade="P";
		else
			grade="F";
		student.setGrade(grade);
		return student;
	}

}
