package org.anudip.crudAppAngular.controller;

import java.util.List;

import org.anudip.crudAppAngular.bean.Student;
import org.anudip.crudAppAngular.dao.StudentDao;
import org.anudip.crudAppAngular.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@CrossOrigin(origins ="http://localhost:10100/") 
@RestController
@RequestMapping("/student-app/")
public class StudentController {
	@Autowired
	private StudentDao studentDao;
	
	@Autowired
	private StudentService service;
	
	
	
  @GetMapping("/id-gen")
	public Integer generateId() {
	     Integer newRollNumber=studentDao.generateStudentRoll();
	   return newRollNumber;
   }
   
   @PostMapping("/student")
	public void saveStudentRecord(@RequestBody  Student newStudent) {
	   Student student=service.totalAndGradeCalculation(newStudent);
	   studentDao.save(student);
  }
   
   @GetMapping("/student")
	public List<Student>showReportPage() {
	   List<Student> studentList=studentDao.displayAllStudents();
	    return studentList;
   }
   
   @GetMapping("/student/{roll}")
	public Student showSingleStudent(@PathVariable int roll ) {
	   return studentDao.findSingleStudent(roll);
	    
      }
   
  /* @PostMapping("/student-find")
  	public ModelAndView showStudentDisplayUpdatePage(@RequestParam("roll") int roll,@RequestParam(required=false,value="Find") String str, @RequestParam(required=false,value="Update") String stk ) {
	   String fileName="";
	   if(str==null)
		   fileName="studentUpdatePage";
	   else if (stk==null)
		   fileName="studentDisplayPage";
	   
	   Student student=studentDao.findSingleStudent(roll);
  	   ModelAndView mv=new ModelAndView(fileName);
  	   mv.addObject("studentRecord",student);
  	    return mv;
        }*/
   
  
}
