package org.anudip.crudAppAngular.dao;

import java.util.List;

import org.anudip.crudAppAngular.bean.Student;



// this interface consists of required database operation on Student class
public interface StudentDao {
	public void save(Student student);
	public List<Student> displayAllStudents();
	public Student findSingleStudent(Integer id);
	public Integer generateStudentRoll();

}
