package org.anudip.crudAppAngular.dao;

import java.util.List;

import org.anudip.crudAppAngular.bean.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

@Repository
@Service
public class StudentDaoImpl implements StudentDao {
	
	@Autowired
    private StudentRepository repository;
	
	@Override
	public void save(Student student) {
		repository.save(student); // both insert & update

	}

	@Override
	public List<Student> displayAllStudents() {
		return repository.findAll(); //select * from student
	}

	@Override
	public Student findSingleStudent(Integer id) {
		
		return repository.findById(id).get(); // select * from student where rollNumber=?
	}

	@Override
	public Integer generateStudentRoll() {
		Integer roll=repository.getMaxRoll();
		if(roll==null)
			roll=1000;
		
		 roll++;
		 return roll;
		 
	}

}
