package org.anudip.crudAppAngular.bean;

import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class Student {
	@Id
	private Integer rollNumber;
	private String studentName;
	private String courseName;
	private Double subject1;
	private Double subject2;
	private Double subject3;
	private Double totalMarks;
	private String grade;
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Student(Integer rollNumber, String studentName, String courseName, Double subject1, Double subject2,
			Double subject3, Double totalMarks, String grade) {
		super();
		this.rollNumber = rollNumber;
		this.studentName = studentName;
		this.courseName = courseName;
		this.subject1 = subject1;
		this.subject2 = subject2;
		this.subject3 = subject3;
		this.totalMarks = totalMarks;
		this.grade = grade;
	}
	

	public Student(Integer rollNumber) {
		super();
		this.rollNumber = rollNumber;
		
	}

	public Integer getRollNumber() {
		return rollNumber;
	}
	public void setRollNumber(Integer rollNumber) {
		this.rollNumber = rollNumber;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public Double getTotalMarks() {
		return totalMarks;
	}
	public void setTotalMarks(Double totalMarks) {
		this.totalMarks = totalMarks;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	
	public Double getSubject1() {
		return subject1;
	}

	public void setSubject1(Double subject1) {
		this.subject1 = subject1;
	}

	public Double getSubject2() {
		return subject2;
	}

	public void setSubject2(Double subject2) {
		this.subject2 = subject2;
	}

	public Double getSubject3() {
		return subject3;
	}

	public void setSubject3(Double subject3) {
		this.subject3 = subject3;
	}

	@Override
	public String toString() {
		return "Student [rollNumber=" + rollNumber + ", studentName=" + studentName + ", courseName=" + courseName
				+ ", totalMarks=" + totalMarks + ", grade=" + grade + "]";
	}
	
}
