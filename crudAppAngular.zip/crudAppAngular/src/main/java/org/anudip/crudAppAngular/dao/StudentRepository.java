package org.anudip.crudAppAngular.dao;


import org.anudip.crudAppAngular.bean.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
// This interface is used for all kind of database transaction from Spring Boot Application

@Repository
public interface StudentRepository extends JpaRepository<Student,Integer> {

 @Query("select max(rollNumber) from Student")
 public Integer getMaxRoll();
}
